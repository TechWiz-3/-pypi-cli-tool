def hello_world():

    print("Hello world")

def main():
    print(":sob:")
